<?php
session_start(); // Start the session if not already started

// Function to check if the user is an admin
function isAdmin() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] == 1;
}

// Redirect if not an admin
if (!isAdmin()) {
    $_SESSION['message']="This page you tried to access is only accessible to the Admin!!";

    echo"<script>window.location='index.php'</script>";
}

// Admin-only content and logic follows here
// ...
