
<?php
date_default_timezone_set("Africa/Nairobi");

require_once 'class.php';
$db = new db_class();

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Contact Us</title>
    <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
   
    <link href="css/sb-admin-2.css" rel="stylesheet">
    

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-text mx-3">VISITOR PANEL</div>
            </a>


            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="about.php">
                    <i class="fas fa-fw fa-book"></i>
                    <span>About Us</span></a>
            </li>
            
            <li class="nav-item active">
                <a class="nav-link" href="contact.php">
                    <i class="fas fa-fw fa-address-book"></i>
                    <span>Contact Us</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="news.php">
                    <i class="fas fa-fw fas fa-television"></i>
                    <span>News and Blogs</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="management.php">
                    <i class="fas fa-fw fas fa-group"></i>
                    <span>Management</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="join.php">
                    <i class="fas fa-fw fas fa-pen-fancy"></i>
                    <span>Why join us</span></a>
            </li>
			
			
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
	
                   
					<!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><Visitor's Account></span>
                                <img class="img-profile rounded-circle"
                                    src="image/admin_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800, align-content-center">Contact Form</h1>
                        
                    </div>

                    <?php
                    // Database connection details
                    $servername = "localhost";
                    $username_db = "cpses_kngqujwjkt"; // Your database username
                    $password_db = "";     // Your database password
                    $dbname = "kngawac1_kngawa"; // Your database name

                    // Create connection
                    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }


                    $message = "";
                    $toastClass = "";
                    $customer_name = " ";
                    $customer_contact = " ";
                    $customer_email = " ";
                    $query_type = "";
                    $customer_message = "";

                    if (isset($_POST['add_contact'])) {
                        $customer_name = $_POST['customer_name'];
                        $customer_contact = $_POST['customer_contact'];
                        $customer_email = $_POST['customer_email'];
                        $query_type = $_POST['query_type_type'];
                        $customer_message = $_POST['customer_message'];

                            // Prepare and bind
                            $stmt = $conn->prepare("INSERT INTO contact (customer_name, customer_contact, customer_email, query_type, customer_message) VALUES (?, ?, ?, ?, ?)");
                            $stmt->bind_param("sssss",$customer_name, $customer_contact, $customer_email, $query_type, $customer_message);

                            if ($stmt->execute()) {
                                $message = "Your message has been submitted. You will hear from us as soon as possible.";
                                $toastClass = "#28a745"; // Success color
                                $stmt->close();

                                return true;
                            } else {
                                $message = "Error: " . $stmt->error;
                                $toastClass = "#dc3545"; // Danger color
                            }


                                            }


                    ?>

<style>
.contact-form {
    max-width: 600px;
    margin: 50px auto;
    padding: 30px;
    background-color: forestgreen;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    font-family: Arial, sans-serif;
}

.form-group {
    margin-bottom: 20px;
}

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
        color: #333;
    }

    .form-group input[type="text"],
    .form-group input[type="email"],
    .form-group textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-sizing: border-box; /* Ensures padding doesn't add to width */
        font-size: 16px;
    }

        .form-group input[type="text"]:focus,
        .form-group input[type="email"]:focus,
        .form-group textarea:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }

.submit-btn {
    background-color: #007bff;
    color: white;
    padding: 12px 25px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
    transition: background-color 0.3s ease;
}

    .submit-btn:hover {
        background-color: #0056b3;
    }
       </style>
<form action="contact.php" method="POST" name= "add_contact" class="contact-form">
    <div class="form-group">
        <label for="customer_name">Name:</label>
        <input type="text" id="customer_name" name="customer_name" required>
    </div>
    <div class="form-group">
        <label for="customer_email">Email:</label>
        <input type="email" id="email" name="customer_email" required>
    </div>
    <div class="form-group">
        <label for="customer_contact">Phone number:</label>
        <input type="number" id="customer_contact" name="customer_contact" required>
    </div>
    <div class="mb-2 mt-2">
        <label for="query_type">Subject</label>
        <select name="query_type" class="form-control" required>
            <option value="">---Select department---</option>"
            <option value="Account">Opening and management of my account</option>"
            <option value="Transactions">Transactions</option>"
            <option value="Loans_and_Savings">Loans and Savings</option>"
            <option value="Technical">Technical assistance</option>"
            <option value="Others">Others</option>"
        </select>


    </div>
    <div class="form-group">
        <label for="customer_message">Message:</label>
        <textarea id="customer_message" name="customer_message" rows="5" required></textarea>
    </div>
    <button type="submit" name= "add_contact" class="submit-btn">Send Message</button>
</form>


